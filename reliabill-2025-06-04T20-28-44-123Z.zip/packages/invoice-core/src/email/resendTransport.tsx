import { Resend } from 'resend';
import { render } from '@react-email/components';
import VerificationEmail from './VerificationEmail';

const resend = new Resend(process.env['RESEND_API_KEY'] ?? '');

export async function sendVerificationEmail(
  to: string,
  magicLink: string,
) {
  const html = render(<VerificationEmail magicLink={magicLink} />);

  await resend.emails.send({
    from: process.env['EMAIL_FROM'] ?? 'ReliaBill <no-reply@example.com>',
    to,
    subject: 'Your ReliaBill sign-in link',
    html,
  });
}
