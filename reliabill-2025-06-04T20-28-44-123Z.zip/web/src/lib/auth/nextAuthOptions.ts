import { PrismaAdapter } from '@next-auth/prisma-adapter';
import { NextAuthOptions } from 'next-auth';
import EmailProvider from 'next-auth/providers/email';
import { PrismaClient } from '@prisma/client';
import { sendVerificationEmail } from '@core/email/resendTransport';

const prisma = new PrismaClient();

export const nextAuthOptions: NextAuthOptions = {
  adapter: PrismaAdapter(prisma),
  providers: [
    EmailProvider({
      maxAge: 30 * 60,
      from: process.env['EMAIL_FROM'],
      async sendVerificationRequest({ identifier, url }) {
        await sendVerificationEmail(identifier, url);
      },
    }),
  ],
  session: { strategy: 'jwt' },
};
