"use client";
import { SessionProvider } from "next-auth/react";
import { cookies } from "next/headers";
import { UserMenu } from "@/components/UserMenu";
import "@/styles/globals.css";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <SessionProvider
          session={null}
          baseUrl={process.env.NEXTAUTH_URL}
          refetchInterval={300}
          refetchOnWindowFocus={false}
          cookies={cookies()}
        >
          <header className="w-full p-4 border-b">
            <nav className="max-w-4xl mx-auto flex justify-between">
              <a href="/" className="text-lg font-bold">Reliabill</a>
              <UserMenu />
            </nav>
          </header>
          <main className="max-w-4xl mx-auto p-4">{children}</main>
        </SessionProvider>
      </body>
    </html>
  );
}
