import { invoiceCore } from './invoice-core';

describe('invoiceCore', () => {
  it('should work', () => {
    expect(invoiceCore()).toEqual('invoice-core');
  });
});
