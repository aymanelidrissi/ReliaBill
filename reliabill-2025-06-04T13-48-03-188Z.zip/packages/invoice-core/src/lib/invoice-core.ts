export function invoiceCore(): string {
  return 'invoice-core';
}
