"use client";
import { SessionProvider } from "next-auth/react";
import { cookies } from "next/headers";
import userMenu from "../components/userMenu";
import "@/styles/globals.css";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>

        <SessionProvider refetchOnWindowFocus={false} refetchInterval={300}>
          <header className="w-full p-4 border-b">
            <nav className="max-w-4xl mx-auto flex justify-between">
              <a href="/" className="text-lg font-bold">Reliabill</a>
              <userMenu />
            </nav>
          </header>
          <main className="max-w-4xl mx-auto p-4">{children}</main>
        </SessionProvider>
      </body>
    </html>
  );
}