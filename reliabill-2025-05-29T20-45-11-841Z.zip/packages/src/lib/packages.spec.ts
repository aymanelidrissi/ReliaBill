import { packages } from './packages';

describe('packages', () => {
  it('should work', () => {
    expect(packages()).toEqual('packages');
  });
});
